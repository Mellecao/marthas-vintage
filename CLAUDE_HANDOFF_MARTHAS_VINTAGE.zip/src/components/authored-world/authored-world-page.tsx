import { SiteHeader } from "./site-header";
import { StyledByMartha } from "./styled-by-martha";
import { ThresholdHero } from "./threshold-hero";
import styles from "./authored-world.module.css";

const PREVIEW_SECTIONS = [
  { id: "collection", eyebrow: "Planned section", title: "The Collection" },
  { id: "beyond-the-wardrobe", eyebrow: "Planned section", title: "Beyond the Wardrobe" },
  { id: "visit", eyebrow: "Planned section", title: "Visit" },
] as const;

export function AuthoredWorldPage() {
  return (
    <div className={styles.page}>
      <a className={styles.skipLink} href="#main-content">Skip to content</a>
      <SiteHeader />
      <main id="main-content">
        <ThresholdHero />
        <StyledByMartha />
        <div className={styles.previewSections} aria-label="Future sections of the redesign">
          {PREVIEW_SECTIONS.map((section) => (
            <section key={section.id} id={section.id} className={styles.previewSection}>
              <p>{section.eyebrow}</p>
              <h2>{section.title}</h2>
            </section>
          ))}
        </div>
      </main>
    </div>
  );
}
